<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Votre titre ici</title>
    <style>
        .accueil {
            display: inline-block;
            padding: 10px 20px;
            margin-left: 745px;
            text-decoration: none;
            color: #fff;
            background-color: #FF0000;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        .accueil:hover {
            background-color: #CC0000;
        }

        .table {
            display: inline-block;
            padding: 10px 20px;
            margin-left: 20px;
            text-decoration: none;
            color: #fff;
            background-color: #0A14FF;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        .table:hover {
            background-color: #060C98;
        }
    </style>
</head>

</html>
<?php
session_start();
require_once 'fonctions.php';

$selected_table = $_SESSION['selected_table'];


switch ($selected_table) {
    case 'G12_Pays':
        include_once 'insertion_G12_Pays.html';
        echo '<a href="accueil.html" class="accueil">Retour à l\'accueil</a>';
        echo '<a href="tableselec.php" class="table">Retour à la table</a>';
        break;

    case 'G12_Clubs':
        include_once 'insertions_G12_Clubs.php';
        echo '<a href="accueil.html" class="accueil">Retour à l\'accueil</a>';
        echo '<a href="tableselec.php" class="table">Retour à la table</a>';
        break;

    case 'G12_Compétitions':
        include_once 'insertion_G12_Compétitions.html';
        echo '<a href="accueil.html" class="accueil">Retour à l\'accueil</a>';
        echo '<a href="tableselec.php" class="table">Retour à la table</a>';
        break;

    case 'G12_participe':
        include_once 'insertion_G12_Participe.php';
        echo '<a href="accueil.html" class="accueil">Retour à l\'accueil</a>';
        echo '<a href="tableselec.php" class="table">Retour à la table</a>';
        break;

    default:
        echo "Table non reconnue.";
        exit;
}



















?>