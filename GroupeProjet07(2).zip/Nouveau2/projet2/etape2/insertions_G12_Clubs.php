<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insertion d'un nouvel élément</title>
    <style>
        body {

            background-image: url('../image/handball.png');
            background-size: 200px;
            background-repeat: no-repeat;
            background-attachment: fixed;
            font-family: Arial, sans-serif;
            background-color: #8EB3F2;
        }

        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }




        form {
            background-color: #BDDFFA;
            padding: 20px;
            max-width: 400px;
            height: 450px;
            margin: 50px auto;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        input[type="text"],
        input[type="number"],
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="reset"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        input[type="reset"] {
            background-color: #f44336;
            float: right;
        }

        input[type="reset"]:hover {
            background-color: #d32f2f;
        }
    </style>
</head>

<body>
    <h2>Insertion d'un nouveau club</h2>
    <form action="inserer_G12_Clubs.php" method="post">


        <p><b>Nom du club :</b></p>
        <input type="text" name="club_nom" required><br><br>

        <p><b>Date de création :</b></p>
        <input type="number" name="club_dcreation" min="1800" max="2023" required><br><br>

        <p><b> Pays :</b></p>
        <?php

        require 'monEnv.php';
        require_once 'fonctions.php';
        $ptrDB = connexion1();
        $codeHTML = '<select  name="pays_id"  required>';
        $query_pays = "SELECT pays_id, pays_nom FROM G12_Pays";
        $result_pays = pg_query($ptrDB, $query_pays);
        if (!$result_pays) {
            echo "<p>Erreur lors de l exécution de la requête.</p>\n";
            exit;
        }
        while ($row = pg_fetch_assoc($result_pays)) {
            $codeHTML .= "<option value='" . $row['pays_id'] . "'";

            $codeHTML .= "'>" . $row['pays_nom'] . "</option>";
        }
        $codeHTML .= " </select><br><br>";

        echo $codeHTML;

        ?>

        <input type="submit" value="Ajouter le club">
        <input type="reset" value="Réinitialiser">
    </form>
</body>

</html>