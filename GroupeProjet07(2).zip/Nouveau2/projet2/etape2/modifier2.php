<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Résultat</title>
    <style>
        body {
            background-image: url('../image/handball.png');
            background-size: 200px;
            background-repeat: no-repeat;
            background-attachment: fixed;
            font-family: Arial, sans-serif;
            background-color: #8EB3F2;
        }



        h2 {
            text-align: center;
            color: #333;
        }

        input[type="reset"],
        input[type="text"],
        input[type="submit"],
        select {
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        input[type="reset"] {
            background-color: #f44336;
            float: right;
        }

        input[type="reset"]:hover {
            background-color: #d32f2f;
        }


        .accueil {
            display: inline-block;
            padding: 10px 20px;
            margin-left: 750px;
            text-decoration: none;
            color: #fff;
            background-color: #FF0000;
           
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        .accueil:hover {
            background-color: #CC0000;
           
        }

        .accueilP {
            display: inline-block;
            padding: 10px 20px;
            margin-left: 650px;
            text-decoration: none;
            color: #fff;
            background-color: #FF0000;
            
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }




        .table {
            display: inline-block;
            padding: 10px 20px;
            margin-left: 20px;
            text-decoration: none;
            color: #fff;
            background-color: #0A14FF;
            
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        .table:hover {
            background-color: #060C98;
            
        }

        ul li {
            margin-bottom: 10px;
            

        }

        ul {
            style = display: inline-block;
            text-align: center;
            list-style: none;
            padding-left: 0;
        }
    </style>
</head>

</html>





<?php
session_start();
include 'fonctions.php';

$selected_table = $_SESSION['selected_table'];
switch ($selected_table) {
    case 'G12_Pays':
        $tab = array(
            'pays_id' => $_POST['pays_id'],
            'pays_nom' => $_POST['pays_nom']
        );
        updatePays($tab);
        echo "<h2>L'enregistrement après modification</h2>";
        getPaysById($tab['pays_id']);
        echo '<a href="accueil.html" class="accueil">Retour à l\'accueil</a>';
        echo '<a href="tableselec.php" class="table">Retour à la table</a>';
        break;

    case 'G12_Clubs':
        $tab = array(
            'club_id' => $_POST['club_id'],
            'club_nom' => $_POST['club_nom'],
            'club_dcreation' => $_POST['club_dcreation'],
            'pays_id' => $_POST['pays_id']
        );
        updateClub($tab);
        echo "<h2>L'enregistrement après modification</h2>";
        getClubById($tab['club_id']);
        echo '<a href="accueil.html" class="accueilP">Retour à l\'accueil</a>';
        echo '<a href="tableselec.php" class="table">Retour à la table</a>';
        break;

    case 'G12_Compétitions':
        $tab = array(
            'compe_id' => $_POST['compe_id'],
            'compe_genre' => $_POST['compe_genre'],
            'compe_nom' => $_POST['compe_nom']
        );
        updateCompetition($tab);
        echo "<h2>L'enregistrement après modification</h2>";
        getCompeById($tab['compe_id']);
        echo '<a href="accueil.html" class="accueil">Retour à l\'accueil</a>';
        echo '<a href="tableselec.php" class="table">Retour à la table</a>';
        break;

    case 'G12_participe':
        $tab = array(
            'cp_id' => $_POST['cp_id'],
            'cb_id' => $_POST['cb_id'],
            'saison' => $_POST['saison'],
            'resultat' => $_POST['resultat']
        );
        updateParticipe($tab);
        echo "<h2>L'enregistrement après modification</h2>";
        getPartById($tab['cp_id'], $tab['cb_id']);
        echo '<a href="accueil.html" class="accueil">Retour à l\'accueil</a>';
        echo '<a href="tableselec.php" class="table">Retour à la table</a>';
        break;


    default:
        echo "Table non reconnue.";
        exit;
}
?>