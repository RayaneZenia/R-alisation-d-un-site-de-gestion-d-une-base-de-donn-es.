
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails</title>
    <style>
        body {
            background-image: url('../image/handball.png');
            background-size: 200px;
            background-repeat: no-repeat;
            background-attachment: fixed;
            font-family: Arial, sans-serif;
            background-color: #8EB3F2;
        }



        h2 {
            text-align: center;
            color: #333;
        }

        input[type="reset"],
        input[type="text"],
        input[type="submit"],
        select {
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        input[type="reset"] {
            background-color: #f44336;
            float: right;
        }

        input[type="reset"]:hover {
            background-color: #d32f2f;
        }


        .accueil {
            display: inline-block;
            padding: 10px 20px;
            margin-left: 650px;
            text-decoration: none;
            color: #fff;
            background-color: #FF0000;
            /* Rouge */
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        .accueil:hover {
            background-color: #CC0000;
        }

        .accueilP {
            display: inline-block;
            padding: 10px 20px;
            margin-left: 747px;
            text-decoration: none;
            color: #fff;
            background-color: #FF0000;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }



        .table {
            display: inline-block;
            padding: 10px 20px;
            margin-left: 20px;
            text-decoration: none;
            color: #fff;
            background-color: #0A14FF;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        .table:hover {
            background-color: #060C98;
        }



        ul li {
            margin-bottom: 10px;
        }

        ul {
            style = display: inline-block;
            text-align: center;
            list-style: none;
            padding-left: 0;
        }
    </style>
</head>

</html>
<?php
session_start();
require_once 'fonctions.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];




    require 'monEnv.php';
    function connexion()
    {
        $strConnex = "host=" . $_ENV['dbHost'] . " dbname=" . $_ENV['dbName'] . " user=" . $_ENV['dbUser'] . " password=" . $_ENV['dbPasswd'];
        $ptrDB = pg_connect($strConnex);
        return $ptrDB;
    }

    $ptrDB = connexion();
    if (!$ptrDB) {
        echo ('Problème de connexion à la base de données.');
        exit();
    }
    $selected_table = $_SESSION['selected_table'];
    switch ($selected_table) {
        case 'G12_Pays':
            getPaysById($id);
            echo '<a href="accueil.html" class="accueilP">Retour à l\'accueil</a>';
            echo '<a href="tableselec.php" class="table">Retour à la table</a>';


            break;
        case 'G12_Clubs':
            getClubById($id);
            echo '<a href="accueil.html" class="accueil">Retour à l\'accueil</a>';
            echo '<a href="tableselec.php" class="table">Retour à la table</a>';
            break;
        case 'G12_Compétitions':
            getCompeById($id);
            echo '<a href="accueil.html" class="accueilP">Retour à l\'accueil</a>';
            echo '<a href="tableselec.php" class="table">Retour à la table</a>';
            break;
        case 'G12_participe':
            if (isset($_GET['cb_id'])) {
                $id2 = $_GET['cb_id'];
                getPartById($id, $id2);
                echo '<a href="accueil.html" class="accueilP">Retour à l\'accueil</a>';
                echo '<a href="tableselec.php" class="table">Retour à la table</a>';
                break;
            }
        default:

            echo "Table non reconnue.";
            exit;
    }
}



?>