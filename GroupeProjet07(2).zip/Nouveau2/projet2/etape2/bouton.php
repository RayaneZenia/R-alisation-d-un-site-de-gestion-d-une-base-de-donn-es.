

<?php
// Ce script PHP gère les actions du formulaire situé dans chaque fonction d'affichage
session_start();
require_once 'fonctions.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $selected_table = $_SESSION['selected_table'];
    if ($selected_table == "G12_participe") {
        $id = $_POST['id1'];
        $id2 = $_POST['id2'];
        $action = $_POST['action'];
    } else {
        if (isset($_POST['id'])) {
            $id = $_POST['id'];
            $action = $_POST['action'];
        } else {
            echo "Le formulaire n'a pas été soumis.";
        }
    }




    switch ($action) {
        case 'Consulter':
            if ($selected_table == "G12_participe") {
                header("Location: consulter.php?id=" . $id . "&cb_id=" . $id2);
                break;
            } else {
                if (isset($_POST['selected_table'])) $_SESSION['selected_table'] = $_POST['selected_table'];
                header("Location: consulter.php?id=$id");

                break;
            }
        case 'Modifier':
            if ($selected_table == "G12_participe") {
                header("Location: modifier.php?id=" . $id . "&cb_id=" . $id2);
                break;
            } else {
                header("Location: modifier.php?id=$id");

                break;
            }

        case 'Supprimer':
            if ($selected_table == "G12_participe") {
                deleteTable($selected_table, $id);
                header("Location: tableselec.php");
            } else {
                deleteTable($selected_table, $id);
                header("Location: tableselec.php");
            }

            break;
        default:
            echo "L'identifiant de l'enregistrement n'a pas été envoyé avec le formulaire.";
            exit;
    }
}



?>

