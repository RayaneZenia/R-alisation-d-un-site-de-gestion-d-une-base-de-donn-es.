<?php
// Ce script php gère l'affichage de la table séléctionnée dans le  formulaire du fichier principal accueil 
session_start();
require_once 'fonctions.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['table'])) {

        $_SESSION['selected_table'] = $_POST['table'];
    }
}


?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau avec Actions</title>
    <style>
        body {
            background-image: url('../image/handball.png');
            background-size: 200px;
            background-repeat: no-repeat;
            background-attachment: fixed;
            font-family: Arial, sans-serif;
            background-color: #8EB3F2;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        .link1 {
            display: inline-block;
            padding: 10px 20px;
            margin-left: 725px;
            text-decoration: none;
            color: #fff;
            background-color: #0A14FF;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        .link1:hover {
            background-color: #060C98;
        }

        .link2 {
            display: inline-block;
            padding: 10px 20px;
            margin: 10px;
            text-decoration: none;
            color: #fff;
            background-color: #ff0000;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        .link2:hover {
            background-color: #cc0000;
        }

        table {
            margin: 0 auto;
            border-collapse: collapse;
            width: 80%;
            max-width: 800px;
        }

        table th,
        table td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;

        }
    </style>

</head>

<body>
    <h2>Table sélectionnée: <?php echo $_SESSION['selected_table']; ?></h2>


    <a href="insertion.php" class="link1">Formulaire d'insertion d'un nouvel enregistrement</a><br><br>

    <?php
    require 'monEnv.php';

    function connexion()
    {

        $strConnex = "host=" . $_ENV['dbHost'] . " dbname=" . $_ENV['dbName'] . " user=" . $_ENV['dbUser'] . " password=" . $_ENV['dbPasswd'];
        $ptrDB = pg_connect($strConnex);
        return $ptrDB;
    }


    $selected_table = $_SESSION['selected_table'];
    switch ($selected_table) {
        case 'G12_Pays':
            Affichepays();
            break;
        case 'G12_Clubs':
            AfficheClubs();
            break;
        case 'G12_Compétitions':
            AfficheCompe();
            break;
        case 'G12_participe':
            AfficheParti();
            break;
        default:

            echo "Table non reconnue.";
            exit;
    }



    ?>

    <br><br>
    <a href="accueil.html" class="link2">Retour à l'accueil</a>
</body>

</html>