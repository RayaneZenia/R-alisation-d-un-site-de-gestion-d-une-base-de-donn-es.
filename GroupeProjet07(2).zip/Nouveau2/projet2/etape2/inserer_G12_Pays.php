<?php
//pour utiliser les fonctions 
require_once '../etape1/G12_pays/fonctions_G12_Pays.php';

//recuperation des donnees
$pays = array(
        'pays_id' => $_GET['pays_id'],
        'pays_nom' => $_GET['pays_nom']
    );


//On verifie si l ID existe deja (On pouvait le faire directement dans le formulaire mais vous avez demander un formulaire.html(falait utiliser du php))
$pays_existants = getPaysById($pays['pays_id']);
if (!empty($pays_existants) && !isset($pays_existants['message'])) {
        // Le pays existe dans la base de données
        echo "L'ID du pays que vous essayez d'insérer existe déjà : ".$pays['pays_id'];
    } else {
        // Le pays n'existe pas dans la base de données
        // Insérer le nouveau pays dans la base de données
    	insertPays($pays);
    	//actualiser
        header("Location: tableselec.php");

    }


?>


