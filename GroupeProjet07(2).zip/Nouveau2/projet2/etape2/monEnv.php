<?php



$_ENV['dbHost']='172.16.20.14';
$_ENV['dbName']='zr223101';
$_ENV['dbUser']='zr223101';
$_ENV['dbPasswd']='20223101';

?>