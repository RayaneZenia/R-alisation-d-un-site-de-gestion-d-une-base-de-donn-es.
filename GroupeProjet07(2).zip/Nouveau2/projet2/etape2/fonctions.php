<?php
require 'monEnv.php';
require_once 'fonctions.php';

function connexion1()
{

    $strConnex = "host=" . $_ENV['dbHost'] . " dbname=" . $_ENV['dbName'] . " user=" . $_ENV['dbUser'] . " password=" . $_ENV['dbPasswd'];
    $ptrDB = pg_connect($strConnex);
    return $ptrDB;
}

function Affichepays()
{
    $ptrDB = connexion1();
    if (!$ptrDB) {
        echo ('pb de connexion');
    } else {

        $requete = "SELECT * FROM G12_Pays ORDER BY pays_id ASC";

        $resultat = pg_query($ptrDB, $requete);

        if (!$resultat) {
            echo "Erreur lors de l'exécution de la requête.";
            exit;
        }



        echo "<table border='0'>";
        echo "<tr>";
        for ($i = 0; $i < pg_num_fields($resultat); $i++) {
            echo "<th>" . pg_field_name($resultat, $i) . "</th>";
        }
        echo "<th style='width: 220px;'>Actions</th>";
        echo "</tr>";
        while ($row = pg_fetch_assoc($resultat)) {
            echo "<tr>";
            foreach ($row as $col_name => $col_value) {
                echo "<td>" . $col_value . "</td>";
            }


            echo
            "<td>
    <form action='bouton.php' method='post' style='display: inline;'>
    <input type='submit' name='action' value='Consulter' >
    <input type='submit' name='action' value='Modifier'>
    <input type='submit' name='action' value='Supprimer' onclick = 'return confirm(\"Etes-vous sur de vouloir supprimer cet enregistrement?\") ' >
    <input type='hidden' name='id' value='" . $row['pays_id'] . "'>

    </form>
    </td>
    </tr>";
        }
        echo "</table>";
    }


    pg_free_result($resultat);
    pg_close($ptrDB);
}

//-----------------------------------------FONCTIONS POUR L'AFFICHAGE--------------------------------------------------------//

function AfficheClubs()
{
    $ptrDB = connexion1();
    if (!$ptrDB) {
        echo ('pb de connexion');
    } else {
        $requete = "SELECT * FROM G12_Clubs ORDER BY club_id ASC";
        $requete2 = "SELECT G12_Clubs.club_id, G12_Pays.pays_nom FROM G12_Pays JOIN G12_Clubs ON G12_Clubs.pays_id = G12_Pays.pays_id";

        $resultat = pg_query($ptrDB, $requete);
        $resultat2 = pg_query($ptrDB, $requete2);

        if (!$resultat || !$resultat2) {
            echo "Erreur lors de l'exécution de la requête.";
            exit;
        }

        // Créer un tableau associatif pour stocker les noms de pays correspondants à chaque club
        $paysClubs = array();
        while ($row = pg_fetch_assoc($resultat2)) {
            $paysClubs[$row['club_id']] = $row['pays_nom'];
        }

        echo "<table border='0'>";
        echo "<tr>";
        for ($i = 0; $i < pg_num_fields($resultat); $i++) {
            if (pg_field_name($resultat, $i) == "pays_id") {
                echo "<th> Pays </th>";
            } else {
                echo "<th>" . pg_field_name($resultat, $i) . "</th>";
            }
        }
        echo "<th style='width: 220px;'>Actions</th>";
        echo "</tr>";
        while ($row = pg_fetch_assoc($resultat)) {
            echo "<tr>";
            foreach ($row as $col_name => $col_value) {
                if ($col_name == "pays_id") {
                    echo "<td>" . $paysClubs[$row['club_id']] . "</td>"; // Utiliser le tableau pour associer le nom de pays correct
                } else {
                    echo "<td>" . $col_value . "</td>";
                }
            }

            echo "<td>
                    <form action='bouton.php' method='post' style='display: inline;'>
                        <input type='submit' name='action' value='Consulter' >
                        <input type='submit' name='action' value='Modifier'>
                        <input type='submit' name='action' value='Supprimer' onclick='return confirm(\"Etes-vous sur de vouloir supprimer cet enregistrement?\") ' >
                        <input type='hidden' name='id' value='" . $row['club_id'] . "'>
                    </form>
                </td>
            </tr>";
        }
        echo "</table>";
    }

    pg_free_result($resultat);
    pg_close($ptrDB);
}





function AfficheCompe()
{
    $ptrDB = connexion1();
    if (!$ptrDB) {
        echo ('pb de connexion');
    } else {

        $requete = "SELECT * FROM G12_Compétitions ORDER BY compe_id ASC ";

        $resultat = pg_query($ptrDB, $requete);

        if (!$resultat) {
            echo "Erreur lors de l'exécution de la requête.";
            exit;
        }



        echo "<table border='0'>";
        echo "<tr>";
        for ($i = 0; $i < pg_num_fields($resultat); $i++) {
            echo "<th>" . pg_field_name($resultat, $i) . "</th>";
        }
        echo "<th style='width: 220px;'>Actions</th>";
        echo "</tr>";
        while ($row = pg_fetch_assoc($resultat)) {
            echo "<tr>";
            foreach ($row as $col_name => $col_value) {
                echo "<td>" . $col_value . "</td>";
            }


            echo
            "<td>
    <form action='bouton.php' method='post' style='display: inline;'>
    <input type='submit' name='action' value='Consulter' >
    <input type='submit' name='action' value='Modifier'>
    <input type='submit' name='action' value='Supprimer' onclick = 'return confirm(\"Etes-vous sur de vouloir supprimer cet enregistrement?\") ' >
    <input type='hidden' name='id' value='" . $row['compe_id'] . "'>
    </form>
    </td>
    </tr>";
        }
        echo "</table>";
    }

    pg_free_result($resultat);
    pg_close($ptrDB);
}



function AfficheParti()
{
    $ptrDB = connexion1();
    if (!$ptrDB) {
        echo ('pb de connexion');
    } else {

        $requete = "SELECT * FROM G12_participe ORDER BY cp_id ASC";
        $requete2 = "SELECT G12_participe.cp_id, G12_Compétitions.compe_nom FROM G12_Compétitions JOIN G12_Participe ON G12_Participe.cp_id = G12_Compétitions.compe_id";
        $requete3 = "SELECT G12_participe.cb_id, G12_Clubs.club_nom FROM G12_Clubs JOIN G12_Participe ON G12_Participe.cb_id = G12_Clubs.club_id";

        $resultat = pg_query($ptrDB, $requete);
        $resultat2 = pg_query($ptrDB, $requete2);
        $resultat3 = pg_query($ptrDB, $requete3);

        if (!$resultat) {
            echo "Erreur lors de l'exécution de la requête.";
            exit;
        }
        $Compe = array();
        while ($row = pg_fetch_assoc($resultat2)) {
            $Compe[$row['cp_id']] = $row['compe_nom'];
        }
        $Clubs = array();
        while ($row = pg_fetch_assoc($resultat3)) {
            $Clubs[$row['cb_id']] = $row['club_nom'];
        }






        echo "<table border='0'>";
        echo "<tr>";
        for ($i = 0; $i < pg_num_fields($resultat); $i++) {
            if (pg_field_name($resultat, $i) == "cp_id") {
                echo "<th> Compétition</th>";
            } elseif (pg_field_name($resultat, $i) == "cb_id") {
                echo "<th> Club</th>";
            } else {
                echo "<th>" . pg_field_name($resultat, $i) . "</th>";
            }
        }
        echo "<th style='width: 220px;'>Actions</th>";
        echo "</tr>";
        while ($row = pg_fetch_assoc($resultat)) {
            echo "<tr>";
            foreach ($row as $col_name => $col_value) {
                if ($col_name == "cp_id") {
                    echo "<td>" . $Compe[$row['cp_id']] . "</td>";
                } elseif ($col_name == "cb_id") {
                    echo "<td>" . $Clubs[$row['cb_id']] . "</td>";
                } else {
                    echo "<td>" . $col_value . "</td>";
                }
            }


            echo
            "<td>
    <form action='bouton.php' method='POST' style='display: inline;'>
    <input type='submit' name='action' value='Consulter' >
    <input type='submit' name='action' value='Modifier'>
    <input type='submit' name='action' value='Supprimer' onclick = 'return confirm(\"Etes-vous sur de vouloir supprimer cet enregistrement?\") ' >
    <input type='hidden' name='id1' value='" . $row['cp_id'] . "'>
    <input type='hidden' name='id2' value='" . $row['cb_id'] . "'>
    </form>
    </td>
    </tr>";
        }
        echo "</table>";
    }


    pg_free_result($resultat);
    pg_close($ptrDB);
}

//---------------------FONCTIONS POUR LES DETAILS DES TABLES (CONSULTER)--------------------------------//

function getPaysById(int $id)
{
    $ptrDB = connexion1();

    $requete = "SELECT * FROM G12_Pays WHERE pays_id = $1";
    pg_prepare($ptrDB, "reqPrepSelectById", $requete);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectById", array($id));

    $requete2 = "SELECT club_nom FROM G12_Clubs WHERE pays_id = $1";
    pg_prepare($ptrDB, "reqClubs", $requete2);
    $ptrQueryClubs = pg_execute($ptrDB, "reqClubs", array($id));

    if ($ptrQuery) {
        echo "<h2>Détails de G12_Pays</h2>";
        echo "<ul>";
        while ($row = pg_fetch_assoc($ptrQuery)) {
            foreach ($row as $col_name => $col_value) {
                echo "<li><b>$col_name</b> : $col_value</li>";
            }
        }
        echo "<li><b>Clubs :</b></li>";
        echo "<ul>";
        while ($row = pg_fetch_assoc($ptrQueryClubs)) {
            foreach ($row as $col_value) {
                echo "<li>$col_value</li>";
            }
        }
        echo "</ul>";
        echo "</ul>";
    } else {
        echo "Erreur lors de l'exécution de la requête.";
    }

    pg_free_result($ptrQuery);
    pg_free_result($ptrQueryClubs);
    pg_close($ptrDB);
}

function getClubById(int $id)
{
    $ptrDB = connexion1();

    $requete = "SELECT G12_Clubs.club_id, G12_Clubs.club_nom, G12_Clubs.club_dcreation, G12_Clubs.pays_id, G12_Pays.pays_nom
    FROM G12_Clubs
    INNER JOIN G12_Pays ON G12_Clubs.pays_id = G12_Pays.pays_id
    WHERE G12_Clubs.club_id = $1";

    pg_prepare($ptrDB, "reqPrepSelectById", $requete);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectById", array($id));;
    if ($ptrQuery) {
        echo "<h2>Détails de G12_Clubs</h2>";
        while ($row = pg_fetch_assoc($ptrQuery)) {
            echo "<ul>";
            echo "<li><b>Id</b>: " . $row['club_id'] . "</li>";
            echo "<li><b>Nom du Club</b>: " . $row['club_nom'] . "</li>";
            echo "<li><b>Date de création</b>: " . $row['club_dcreation'] . "</li>";
            echo "<li><b>Pays du club</b>: " . $row['pays_nom'] . "</li>";
            echo "</ul>";


            echo "<form action='bouton.php' method='POST' style='display: inline;'>";
            echo "<p><b>Consultation des détails du Pays :</b></p>";
            echo "<input type='hidden' name='id' value='" . $row['pays_id'] . "'>";
            echo "<input type='hidden' name='selected_table' value='G12_Pays'>"; // Par défaut, la valeur est G12_Pays
            echo "<input type='submit' name='action' value='Consulter'>";
            echo "</form>";
        }
    } else {
        echo "Erreur lors de l'exécution de la requête.";
    }

    pg_free_result($ptrQuery);
    pg_close($ptrDB);
}
function getCompeById(int $id)
{
    $ptrDB = connexion1();

    $requete = "SELECT * FROM G12_Compétitions WHERE compe_id = $1";
    pg_prepare($ptrDB, "reqPrepSelectById", $requete);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectById", array($id));

    $requete2 = "SELECT club_nom FROM G12_Clubs WHERE club_id = ANY (SELECT cb_id FROM G12_participe WHERE cp_id = $1)";
    pg_prepare($ptrDB, "reqClubs", $requete2);
    $ptrQueryClubs = pg_execute($ptrDB, "reqClubs", array($id));

    if ($ptrQuery) {
        echo "<h2>Détails de G12_Compétitions</h2>";
        echo "<ul>";
        while ($row = pg_fetch_assoc($ptrQuery)) {
            foreach ($row as $col_name => $col_value) {
                echo "<li><b>$col_name</b> : $col_value</li>";
            }
        }
        echo "<li><b>Clubs Participants :</b></li>";
        echo "<ul>";



        if ($ptrQueryClubs && pg_num_rows($ptrQueryClubs) > 0) {
            while ($row = pg_fetch_assoc($ptrQueryClubs)) {
                foreach ($row as $col_value) {
                    echo "<li>$col_value</li>";
                }
            }

            echo "</ul>";
        } else {
            echo "<li>AUCUN CLUB</li>";
        }
        echo "</ul>";
    } else {
        echo "Erreur lors de l'exécution de la requête.";
    }

    pg_free_result($ptrQuery);
    pg_free_result($ptrQueryClubs);
    pg_close($ptrDB);
}



function getPartById(int $id1, int $id2)
{
    $ptrDB = connexion1();

    $requete = "SELECT G12_participe.saison, G12_participe.resultat, G12_Compétitions.compe_nom, G12_Clubs.club_nom
                FROM G12_participe
                INNER JOIN G12_Compétitions ON G12_participe.cp_id = G12_Compétitions.compe_id
                INNER JOIN G12_Clubs ON G12_participe.cb_id = G12_Clubs.club_id
                WHERE G12_participe.cp_id = $1 AND G12_participe.cb_id = $2";
    pg_prepare($ptrDB, "reqPrepSelectById", $requete);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectById", array($id1, $id2));

    if ($ptrQuery) {
        echo "<h2>Détails de G12_participe</h2>";
        while ($row = pg_fetch_assoc($ptrQuery)) {
            echo "<ul>";
            echo "<li><b>Compétition</b>: " . $row['compe_nom'] . "</li>";
            echo "<li><b>Club</b>: " . $row['club_nom'] . "</li>";
            echo "<li><b>Saison</b>: " . $row['saison'] . "</li>";
            echo "<li><b>Résultat</b>: " . $row['resultat'] . "</li>";
            echo "</ul>";
        }
    } else {
        echo "Erreur lors de l'exécution de la requête.";
    }

    pg_free_result($ptrQuery);
    pg_close($ptrDB);
}








// SI VOUS REMARQUEZ Y A DEUX FONCTIONS getTABLE qui sont identiques ! MAIS attention l'une renvoie un tableau et l'autre renvoie rien, dans ma partie modifier DANS LES FORMULAIRES j'ai besoin d'une fonction qui me retourne ce tableau pour afficher les valeurs par défauts 
function getPays(int $id): array
{
    $ptrDB = connexion1();

    $ptrquery = "SELECT * FROM G12_Pays WHERE pays_id = $1";

    pg_prepare($ptrDB, "reqPrepSelectById", $ptrquery);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectById", array($id));

    if (isset($ptrQuery))
        $resu = pg_fetch_assoc($ptrQuery);
    if (empty($resu))
        $resu =  array("message" => "Identifiant de Pays non valide : $id");

    pg_free_result($ptrQuery);
    pg_close($ptrDB);

    return $resu;
}



function getClub(int $id): array
{
    $ptrDB = connexion1();

    $ptrquery = "SELECT * FROM G12_Clubs WHERE club_id = $1";

    pg_prepare($ptrDB, "reqPrepSelectById", $ptrquery);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectById", array($id));

    if (isset($ptrQuery))
        $resu = pg_fetch_assoc($ptrQuery);
    if (empty($resu))
        $resu =  array("message" => "Identifiant de Club non valide : $id");

    pg_free_result($ptrQuery);
    pg_close($ptrDB);

    return $resu;
}

function getCompetitions(int $id): array
{
    $ptrDB = connexion1();

    $ptrquery = "SELECT * FROM G12_Compétitions WHERE compe_id = $1";

    pg_prepare($ptrDB, "reqPrepSelectById", $ptrquery);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectById", array($id));

    if (isset($ptrQuery))

        $resu = pg_fetch_assoc($ptrQuery);

    if (empty($resu))
        $resu =  array("message" => "Identifiant de COmpétition non valide : $id");

    pg_free_result($ptrQuery);

    pg_close($ptrDB);

    return $resu;
}

function getParticipe(int $cp_id, int $cb_id): array
{
    $ptrDB = connexion1();

    $ptrquery = "SELECT * FROM G12_participe WHERE cp_id = $1 AND cb_id = $2";

    pg_prepare($ptrDB, "reqPrepSelectById", $ptrquery);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectById", array($cp_id, $cb_id));

    if (isset($ptrQuery))
        $resu = pg_fetch_assoc($ptrQuery);
    if (empty($resu))
        $resu =  array("message" => "Identifiants de Participe non valide : $cp_id,$cb_id");

    pg_free_result($ptrQuery);
    pg_close($ptrDB);

    return $resu;
}





//---------------------------------------------------FONCTIONS DE MAJ-------------------------------------//

function updatePays(array $pays): array
{
    $ptrDB = connexion1();

    $query = "UPDATE G12_pays SET pays_nom = $2 WHERE pays_id = $1";
    pg_prepare($ptrDB, "reqPrepUpdate", $query);


    $ptrQuery = pg_execute($ptrDB, "reqPrepUpdate", array(
        $pays['pays_id'],
        $pays['pays_nom']
    ));

    return getPays($pays['pays_id']);
}



function updateClub(array $club): array
{
    $ptrDB = connexion1();

    $query = "UPDATE G12_Clubs SET club_nom = $2 WHERE club_id = $1";
    pg_prepare($ptrDB, "reqPrepUpdate", $query);


    $ptrQuery = pg_execute($ptrDB, "reqPrepUpdate", array(
        $club['club_id'],
        $club['club_nom']
    ));

    return getClub($club['club_id']);
}


function updateCompetition(array $competition): array
{
    $ptrDB = connexion1();


    $query = "UPDATE G12_Compétitions SET compe_genre = $2, compe_nom = $3 WHERE compe_id = $1";
    pg_prepare($ptrDB, "reqPrepUpdate", $query);


    $ptrQuery = pg_execute($ptrDB, "reqPrepUpdate", array(
        $competition['compe_id'],
        $competition['compe_genre'],
        $competition['compe_nom'],

    ));

    return getCompetitions($competition['compe_id']);
}

function updateParticipe(array $participe): array
{
    $ptrDB = connexion1();

    $query = "UPDATE G12_Participe SET saison = $3, resultat=$4 WHERE cp_id = $1 AND cb_id = $2";
    pg_prepare($ptrDB, "reqPrepUpdate", $query);


    $ptrQuery = pg_execute($ptrDB, "reqPrepUpdate", array(
        $participe['cp_id'],
        $participe['cb_id'],
        $participe['saison'],
        $participe['resultat']
    ));

    return getParticipe($participe['cp_id'], $participe['cb_id']);
}







//---------------------------------------FONCTIONS DE SUPPRESSION----------------------------------------------//
function deletePays(string $id): void
{
    $ptrDB = connexion1();

    $query = "DELETE FROM G12_pays WHERE pays_id = $1";
    pg_prepare($ptrDB, "reqPrepDelete", $query);


    pg_execute($ptrDB, "reqPrepDelete", array($id));

    pg_close($ptrDB);
}


function deleteParticipe(int $cp_id, int $cb_id): bool
{
    $ptrDB = connexion1();

    $query = "DELETE FROM G12_Participe WHERE cp_id = $1 AND cb_id=$2";
    pg_prepare($ptrDB, "reqPrepDelete", $query);


    $result = pg_execute($ptrDB, "reqPrepDelete", array($cp_id, $cb_id));

    pg_close($ptrDB);


    if ($result) {
        return true;
    } else {
        return false;
    }
}

function deleteCompetition(string $id): void
{
    $ptrDB = connexion1();


    $query = "DELETE FROM G12_Compétitions WHERE compe_id = $1";
    pg_prepare($ptrDB, "reqPrepDelete", $query);


    pg_execute($ptrDB, "reqPrepDelete", array($id));



    pg_close($ptrDB);
}


function deleteClub(string $id): bool
{
    $ptrDB = connexion1();

    $query = "DELETE FROM G12_Clubs WHERE club_id = $1";
    pg_prepare($ptrDB, "reqPrepDelete", $query);


    $result = pg_execute($ptrDB, "reqPrepDelete", array($id));
    pg_close($ptrDB);



    if ($result) {
        return true;
    } else {
        return false;
    }
}



function deleteTable(string $table, int $id): void
{
    //$supprimer = false;
    switch ($table) {
        case 'G12_Pays':
            deletePays($id);
            break;
        case 'G12_Clubs':
            deleteClub($id);
            break;
        case 'G12_Compétitions':
            deleteCompetition($id);
            break;
        case 'G12_participe':
            $id2 = $_POST['id2'];
            deleteParticipe($id, $id2);
            break;
        default:

            echo "Table non reconnue.";
            exit;
    }
}
