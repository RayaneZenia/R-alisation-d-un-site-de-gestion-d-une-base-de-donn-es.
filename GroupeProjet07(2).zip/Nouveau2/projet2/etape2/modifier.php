<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modification</title>
    <style>
        .accueil {
            display: inline-block;
            padding: 10px 20px;
            margin-left: 745px;
            text-decoration: none;
            color: #fff;
            background-color: #FF0000;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        .accueil:hover {
            background-color: #CC0000;
        }

        .table {
            display: inline-block;
            padding: 10px 20px;
            margin-left: 20px;
            text-decoration: none;
            color: #fff;
            background-color: #0A14FF;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
        }

        .table:hover {
            background-color: #060C98;
        }
    </style>
</head>

</html>
<?php
session_start();
require_once 'fonctions.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    require 'monEnv.php';
    function connexion()
    {
        $strConnex = "host=" . $_ENV['dbHost'] . " dbname=" . $_ENV['dbName'] . " user=" . $_ENV['dbUser'] . " password=" . $_ENV['dbPasswd'];
        $ptrDB = pg_connect($strConnex);
        return $ptrDB;
    }

    $ptrDB = connexion();
    if (!$ptrDB) {
        echo ('Problème de connexion à la base de données.');
        exit();
    }
    $selected_table = $_SESSION['selected_table'];
    switch ($selected_table) {
        case 'G12_Pays':
            echo "<h2>Modifier les détails de Pays : </h2>";
            include '../etape1/G12_pays/insertion_G12_Pays.php';
            echo '<a href="accueil.html" class="accueil">Retour à l\'accueil</a>';
            echo '<a href="tableselec.php" class="table">Retour à la table</a>';
            break;
        case 'G12_Clubs':
            echo "<h2>Modifier les détails de Clubs : </h2>";
            include '../etape1/G12_Clubs/insertions_G12_Clubs.php';
            echo '<a href="accueil.html" class="accueil">Retour à l\'accueil</a>';
            echo '<a href="tableselec.php" class="table">Retour à la table</a>';

            break;
        case 'G12_Compétitions':
            echo "<h2>Modifier les détails de la compétition : </h2>";
            include '../etape1/G12_compétition/insertion_G12_Compétitions.php';
            echo '<a href="accueil.html" class="accueil">Retour à l\'accueil</a>';
            echo '<a href="tableselec.php" class="table">Retour à la table</a>';


            break;

        case 'G12_participe':
            if (isset($_GET['cb_id'])) {
                $id2 = $_GET['cb_id'];
                echo "<h2>Modifier les détails de participe : </h2>";
                include '../etape1/G12_participe/insertion_G12_Participe.php';
                echo '<a href="accueil.html" class="accueil">Retour à l\'accueil</a>';
                echo '<a href="tableselec.php" class="table">Retour à la table</a>';
            }
            break;





        default:
            echo "Table non reconnue.";
            exit;
    }
}
?>