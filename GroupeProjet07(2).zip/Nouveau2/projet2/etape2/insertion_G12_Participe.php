<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insertion d'une nouvelle participation</title>
    <style>
        body {

            background-image: url('../image/handball.png');
            background-size: 200px;
            background-repeat: no-repeat;
            background-attachment: fixed;
            font-family: Arial, sans-serif;
            background-color: #8EB3F2;
        }

        form {
            background-color: #BDDFFA;
            padding: 20px;
            max-width: 400px;
            height: 600px;
            margin: 50px auto;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        input[type="reset"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="text"],
        input[type="number"],
        input[type="submit"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        input[type="reset"] {
            background-color: #f44336;
            float: right;
        }

        input[type="reset"]:hover {
            background-color: #d32f2f;
        }
    </style>
</head>

<body>

    <?php
    require 'monEnv.php';
    require_once 'fonctions.php';

    ?>
    <h2>Insertion d'une nouvelle participation</h2>
    <form action="inserer_G12_participe.php" method="post">

        <p><b>ID de la compétition :</b></p>
        <?php

        $ptrDB = connexion1();
        $codeHTML = '<select  name="cp_id"  required>';
        $query_compe = "SELECT compe_id, compe_nom FROM G12_Compétitions";
        $result_compe = pg_query($ptrDB, $query_compe);
        if (!$result_compe) {
            echo "<p>Erreur lors de l exécution de la requête.</p>\n";
            exit;
        }
        while ($row = pg_fetch_assoc($result_compe)) {
            $codeHTML .= "<option value='" . $row['compe_id'] . "'";

            $codeHTML .= "'>" . $row['compe_nom'] . "</option>";
        }
        $codeHTML .= " </select><br><br>";
        echo $codeHTML;

        ?>

        <p><b> Club :</b></p>
        <?php
        $ptrDB = connexion1();
        $codeHTML = '<select  name="cb_id"  required>';
        $query_compe = "SELECT club_id, club_nom FROM G12_Clubs";
        $result_compe = pg_query($ptrDB, $query_compe);
        if (!$result_compe) {
            echo "<p>Erreur lors de l exécution de la requête.</p>\n";
            exit;
        }
        while ($row = pg_fetch_assoc($result_compe)) {
            $codeHTML .= "<option value='" . $row['club_id'] . "'";

            $codeHTML .= "'>" . $row['club_nom'] . "</option>";
        }
        $codeHTML .= " </select><br><br>";
        echo $codeHTML;

        ?>

        <p><b>Saison :</b></p>
        <input type="number" name="saison" min="1800" max="2024" required><br><br>

        <p><b>Résultat :</b></p>

        <select name="resultat" required>
            <option value="Vainqueur">Vainqueur</option>
            <option value="Finaliste">Finaliste</option>
        </select><br><br>

        <input type="submit" value="Ajouter la participation">
        <input type="reset" value="Réinitialiser">
    </form>
</body>

</html>