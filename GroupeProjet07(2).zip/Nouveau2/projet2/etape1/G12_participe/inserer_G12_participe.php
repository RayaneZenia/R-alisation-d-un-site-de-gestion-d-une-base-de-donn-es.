<?php
//pour utiliser les fonctions 
require 'fonctions_G12_Participe.php';
require '../G12_Clubs/fonction_G12_Clubs.php';
require '../G12_compétition/fonctions_G12_Compétitions.php';

//recuperation des donnees
$participe = array(
        'cp_id' => $_POST['cp_id'],
        'cb_id' => $_POST['cb_id'],
        'saison' => $_POST['saison'],
        'resultat' => $_POST['resultat'] 
    );


                insertParticipe($participe);
                header("Location: tableselec.php");
     





      

















      













?>