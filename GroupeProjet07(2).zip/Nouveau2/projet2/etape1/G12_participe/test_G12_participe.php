<?php
require_once 'fonctions_G12_Participe.php';
require_once '../G12_Clubs/fonction_G12_Clubs.php';
require_once '../G12_compétition/fonctions_G12_Compétitions.php';

//Test de getParticipeById() 
echo " A<br />";
print_r(getParticipeById(1, 4));
echo " A<br />";
echo " B<br />";
print_r(getParticipeById(111, 111));
echo " B<br />";

// Test de insertParticipe() 
echo " C<br />";
$participe = getParticipeById(1,4);
//Création de l'id du club qu'on veut insérer
$club = getClubById(118);
$club['club_id'] = 400;
insertClub($club);

//Création de l'id de la compétition qu'on veut insérer
$Competition = getCompetitionsById(116);
$Competition['compe_id'] = 500;
insertCompetition($Competition);

//Insértion des deux ID qu'on vient de créer
$participe['cp_id'] = 500;
$participe['cb_id'] = 400;

insertParticipe($participe);
echo " C<br />";
echo " D<br />";
print_r(getParticipeById(500, 400));
echo " D<br />";

// Test de updateParticipe() 
echo " E<br />";
$Participe = getParticipeById(500, 400);
print_r($Participe);
echo " E<br />";
echo " F<br />";
$Participe['saison'] = 2024;
print_r(updateParticipe($Participe));
echo " F<br />";

// Test de deleteParticipe() 
echo " G<br />";
deleteParticipe(500, 400);
print_r(getParticipeById(500, 400));
echo " G<br />";

// Test de getAllParticipes() 
echo " H<br />";
print_r(getAllParticipe());
echo " H<br />";

?>
