<?php
require 'monEnv.php';

function connexion() {

    $strConnex = "host=" . $_ENV['dbHost'] . " dbname=" . $_ENV['dbName'] . " user=" . $_ENV['dbUser'] . " password=" . $_ENV['dbPasswd'];
    $ptrDB = pg_connect($strConnex);
    return $ptrDB;
}


function getParticipeById(int $cp_id, int $cb_id) : array {
    $ptrDB = connexion();

	$ptrquery = "SELECT * FROM G12_participe WHERE cp_id = $1 AND cb_id = $2";

 pg_prepare($ptrDB,"reqPrepSelectById",$ptrquery);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectById", array($cp_id,$cb_id));

    if (isset($ptrQuery))
        $resu = pg_fetch_assoc($ptrQuery);
        if (empty($resu))
            $resu =  array("message" => "Identifiants de Participe non valide : $cp_id,$cb_id");
            
    pg_free_result($ptrQuery);
    pg_close($ptrDB);

    return $resu;
}

function getAllParticipe() : array {
    $ptrDB = connexion();

    $query = "SELECT * FROM G12_participe";
    pg_prepare($ptrDB, "reqPrepSelectAll", $query);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectAll", array());

    $resu = array();

    if (isset($ptrQuery)) {
        while ($row = pg_fetch_assoc($ptrQuery)) {
            $resu[] = $row;
        }
    }
    pg_free_result($ptrQuery);
    pg_close($ptrDB);
    return $resu;
}

function insertParticipe(array $participe) : array {
    $ptrDB = connexion();

    $query = "INSERT INTO G12_participe (cp_id, cb_id,saison,resultat) VALUES ($1, $2,$3,$4)";
    pg_prepare($ptrDB, "reqPrepInsert", $query);

    // Exécution de la requête INSERT avec les valeurs fournies
    $ptrQuery = pg_execute($ptrDB, "reqPrepInsert", array(
        $participe['cp_id'],
        $participe['cb_id'],
        $participe['saison'],
        $participe['resultat']
        
    ));

    return getParticipeById($participe['cp_id'],$participe['cb_id']);
}

function updateParticipe(array $participe): array  {
    $ptrDB = connexion();

     $query = "UPDATE G12_Participe SET saison = $3, resultat=$4 WHERE cp_id = $1 AND cb_id = $2";
    pg_prepare($ptrDB, "reqPrepUpdate", $query);

   
    $ptrQuery = pg_execute($ptrDB, "reqPrepUpdate", array(
        $participe['cp_id'],
        $participe['cb_id'],
        $participe['saison'],
        $participe['resultat']
    ));

    return getParticipeById($participe['cp_id'],$participe['cb_id']);
}

function deleteParticipe(int $cp_id, int $cb_id): void  {
    $ptrDB = connexion();

     $query = "DELETE FROM G12_Participe WHERE cp_id = $1 AND cb_id=$2";
    pg_prepare($ptrDB, "reqPrepDelete", $query);


    pg_execute($ptrDB, "reqPrepDelete", array($cp_id,$cb_id));

    pg_close($ptrDB);
}
?>
