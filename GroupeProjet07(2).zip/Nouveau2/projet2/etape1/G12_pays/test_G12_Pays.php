<?php
require_once 'fonctions_G12_Pays.php';

// Test de getPaysById() 
echo " A<br />";
print_r(getPaysById(2));
echo " A<br />";
echo " B<br />";
print_r(getPaysById(111));
echo " B<br />";

// Test de insertPays() 
echo " C<br />";
$pays = getPaysById('1');
$pays['pays_id'] = '115';
print_r(insertPays($pays));
echo " C<br />";
echo " D<br />";
print_r(getPaysById('115'));
echo " D<br />";

// Test de updatePays() 
echo " E<br />";
$pays = getPaysById('115');
print_r($pays);
echo " E<br />";
echo " F<br />";
$pays['pays_nom'] = 'Espagne';
print_r(updatePays($pays));
echo " F<br />";

// Test de deletePays() 
echo " G<br />";
deletePays('115');
print_r(getPaysById('115'));
echo " G<br />";

// Test de getAllPays() 
echo " H<br />";
print_r(getAllPays());
echo " H<br />";

?>
