
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insértion d'un nouvel élément</title>
    <style>
          body {
         
         background-image: url('../image/handball.png');
        background-size: 200px;
        background-repeat: no-repeat;
        background-attachment: fixed;
        font-family: Arial, sans-serif;
        background-color:#8EB3F2 ;
        }
      
        form {
            background-color: #BDDFFA;
            padding: 20px;
            max-width: 400px;
            height: 350px;
            margin: 50px auto;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        input[type="text"],
        input[type="reset"],
       input[type="number"],
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
         input[type="reset"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
       input[type="reset"] {
            background-color: #f44336;
            float: right;
        }
        input[type="reset"]:hover {
            background-color: #d32f2f;
        }
    </style>
</head>

<body>
    <?php
        require 'monEnv.php';
        require_once'../etape2/fonctions.php';
        $pays_details = getPays($id);
    ?>

    <form action="modifier2.php" method="post">

        <p><b>Id du pays :</b></p>
        <input type="text"  name="pays_id" value="<?php echo $pays_details['pays_id']; ?>" readonly><br><br>
        
        <p><b>Nom du pays :</b></p>
        <input type="text"  name="pays_nom" value="<?php echo $pays_details['pays_nom']; ?>"size="15" required><br><br>
        
        <input type="submit" value="Modifier le pays">
        <input type="reset" value="Réinitialiser">
    </form>
</body>
</html>
