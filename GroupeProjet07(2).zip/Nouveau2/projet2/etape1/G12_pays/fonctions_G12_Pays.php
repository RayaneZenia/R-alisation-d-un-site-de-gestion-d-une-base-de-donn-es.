<?php
require 'monEnv.php';

function connexion1() {

    $strConnex = "host=" . $_ENV['dbHost'] . " dbname=" . $_ENV['dbName'] . " user=" . $_ENV['dbUser'] . " password=" . $_ENV['dbPasswd'];
    $ptrDB = pg_connect($strConnex);
    return $ptrDB;
}


function getPaysById(int $id) : array {
    $ptrDB = connexion1();

    $ptrquery = "SELECT * FROM G12_Pays WHERE pays_id = $1";

 pg_prepare($ptrDB,"reqPrepSelectById",$ptrquery);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectById", array($id));

    if (isset($ptrQuery))
        $resu = pg_fetch_assoc($ptrQuery);
        if (empty($resu))
            $resu =  array("message" => "Identifiant de Pays non valide : $id");
            
    pg_free_result($ptrQuery);
    pg_close($ptrDB);

    return $resu;
}

function getAllPays() : array {
    $ptrDB = connexion1();

    $query = "SELECT * FROM G12_Pays";
    pg_prepare($ptrDB, "reqPrepSelectAll", $query);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectAll", array());

    $resu = array();

    if (isset($ptrQuery)) {
        while ($row = pg_fetch_assoc($ptrQuery)) {
            $resu[] = $row;
        }
    }
    pg_free_result($ptrQuery);
    pg_close($ptrDB);
    return $resu;
}

function insertPays(array $pays) : array {
    $ptrDB = connexion1();

    $query = "INSERT INTO G12_Pays (pays_id, pays_nom) VALUES ($1, $2)";
    pg_prepare($ptrDB, "reqPrepInsert", $query);

    // Exécution de la requête INSERT avec les valeurs fournies
    $ptrQuery = pg_execute($ptrDB, "reqPrepInsert", array(
        $pays['pays_id'],
        $pays['pays_nom']
    ));

    return getPaysById($pays['pays_id']);
}

function updatePays(array $pays): array  {
    $ptrDB = connexion1();

     $query = "UPDATE G12_pays SET pays_nom = $2 WHERE pays_id = $1";
    pg_prepare($ptrDB, "reqPrepUpdate", $query);

   
    $ptrQuery = pg_execute($ptrDB, "reqPrepUpdate", array(
        $pays['pays_id'],
        $pays['pays_nom']
    ));

    return getPaysById($pays['pays_id']);
}

function deletePays(string $id): void  {
    $ptrDB = connexion1();

     $query = "DELETE FROM G12_pays WHERE pays_id = $1";
    pg_prepare($ptrDB, "reqPrepDelete", $query);


    pg_execute($ptrDB, "reqPrepDelete", array($id));

    pg_close($ptrDB);
}
?>
