<?php
require_once 'fonctions_G12_Compétitions.php';

// Test de getCompetitionById() 
echo " A<br />";
print_r(getCompetitionsById(2));
echo " A<br />";
echo " B<br />";
print_r(getCompetitionsById(111));
echo " B<br />";

// Test de insertCompetition() 
echo " C<br />";
$Competition = getCompetitionsById('200');
print_r(insertCompetition($Competition));
echo " C<br />";
echo " D<br />";
print_r(getCompetitionsById('12'));
echo " D<br />";


 //Test de updateCompetition() 
echo " E<br />";
$Competition = getCompetitionsById('1');
print_r($Competition);
echo " E<br />";
echo " F<br />";
$Competition['compe_nom'] = 'Ligue des champions EU';
print_r(updateCompetition($Competition));
echo " F<br />";


//Test de deleteCompetition() 
echo " G<br />";
deleteCompetition('12');
print_r(getCompetitionsById('12'));
echo " G<br />";

// Test de getAllCompetition() 
echo " H<br />";
print_r(getAllCompetitions());
echo " H<br />";
?>