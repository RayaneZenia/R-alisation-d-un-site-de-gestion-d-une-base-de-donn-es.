<?php
require 'monEnv.php';

function connexion3() {

    $strConnex = "host=" . $_ENV['dbHost'] . " dbname=" . $_ENV['dbName'] . " user=" . $_ENV['dbUser'] . " password=" . $_ENV['dbPasswd'];
    $ptrDB = pg_connect($strConnex);
    return $ptrDB;
}

function getCompetitionsById(int $id) : array{
    $ptrDB = connexion3();

    $ptrquery = "SELECT * FROM G12_Compétitions WHERE compe_id = $1";

    pg_prepare($ptrDB,"reqPrepSelectById",$ptrquery);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectById", array($id));

    if (isset($ptrQuery))

        $resu = pg_fetch_assoc($ptrQuery);

        if (empty($resu))
            $resu =  array("message" => "Identifiant de COmpétition non valide : $id");

    pg_free_result($ptrQuery);
 
    pg_close($ptrDB);

    return $resu;
}

function getAllCompetitions() : array{
    $ptrDB = connexion3();

    $query = "SELECT * FROM G12_Compétitions";
    pg_prepare($ptrDB, "reqPrepSelectAll", $query);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectAll", array());

    $resu = array();

    if (isset($ptrQuery)) {
     
        while ($row = pg_fetch_assoc($ptrQuery)) {
            $resu[] = $row;
        }
    }
    pg_free_result($ptrQuery);
    pg_close($ptrDB);
    return $resu;
}

function insertCompetition(array $competition) : void {
    $ptrDB = connexion3();


    $query = "INSERT INTO G12_Compétitions (compe_genre, compe_nom) VALUES ($1, $2)";
    pg_prepare($ptrDB, "reqPrepInsert", $query);

    // Exécution de la requête INSERT avec les valeurs fournies
    $ptrQuery = pg_execute($ptrDB, "reqPrepInsert", array(
        $competition['compe_genre'],
        $competition['compe_nom']
       
    ));
}

function updateCompetition(array $competition): array  {
    $ptrDB = connexion3();


     $query = "UPDATE G12_Compétitions SET compe_genre = $2, compe_nom = $3 WHERE compe_id = $1";
    pg_prepare($ptrDB, "reqPrepUpdate", $query);


    $ptrQuery = pg_execute($ptrDB, "reqPrepUpdate", array(
        $competition['compe_id'],
        $competition['compe_genre'],
        $competition['compe_nom'],
        
    ));

    return getCompetitionsById($competition['compe_id']);
}

function deleteCompetition(string $id): void  {
    $ptrDB = connexion3();


     $query = "DELETE FROM G12_Compétitions WHERE compe_id = $1";
    pg_prepare($ptrDB, "reqPrepDelete", $query);


    pg_execute($ptrDB, "reqPrepDelete", array($id));

    pg_close($ptrDB);

}

?>
