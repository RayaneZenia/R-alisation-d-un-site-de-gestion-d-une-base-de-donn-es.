<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insertion d'une nouvelle compétition</title>
    <style>
           body {
         
         background-image: url('../image/handball.png');
        background-size: 200px;
        background-repeat: no-repeat;
        background-attachment: fixed;
        font-family: Arial, sans-serif;
        background-color:#8EB3F2 ;
        }

        form {
            background-color: #BDDFFA;
            padding: 20px;
            max-width: 400px;
            height: 475px;
            margin: 50px auto;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
         input[type="reset"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        input[type="text"],
        input[type="submit"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
          input[type="reset"] {
            background-color: #f44336;
            float: right;
        }
        input[type="reset"]:hover {
            background-color: #d32f2f;
        }
    </style>
</head>
<body>
        <?php
        require 'monEnv.php';
        require_once'../etape2/fonctions.php';
        $compe_details = getCompetitions($id);
    ?>
    <form action="modifier2.php" method="post">
        <p><b>ID de la compétition :</b></p>
        <input type="text"  name="compe_id" value="<?php echo $compe_details['compe_id']; ?>" readonly><br><br>

        <p><b>Genre de la compétition :</b></p>
        <select name="compe_genre" required>
            <option value="Féminine">Féminine</option>
            <option value="Masculine">Masculine</option>
        </select><br><br>
        
        <p><b>Nom de la compétition :</b></p>
        <?php
        $ptrDB = connexion1();
        $codeHTML = '<select  name="compe_nom"  required>';
        $query_compe="SELECT compe_id, compe_nom FROM G12_Compétitions";
        $result_compe = pg_query($ptrDB,$query_compe);
        if (!$result_compe) {
        echo "<p>Erreur lors de l exécution de la requête.</p>\n";
        exit;
        }
        while ($row = pg_fetch_assoc($result_compe)) {
            $codeHTML .= "<option value='" . htmlentities($row["compe_nom"], ENT_QUOTES) . "'";

            if($compe_details['compe_id'] == $row['compe_id']) {
                $codeHTML .= " selected = 'selected'";
            }

            $codeHTML .= "'>".$row['compe_nom']."</option>";
        }
        $codeHTML.=" </select><br><br>";
        echo $codeHTML;
        
        ?>
    
        <input type="submit" value="Modifier la compétition">
        <input type="reset" value="Réinitialiser">
    </form>
</body>
</html>
