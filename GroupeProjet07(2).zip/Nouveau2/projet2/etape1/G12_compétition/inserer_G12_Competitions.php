<?php
//pour utiliser les fonctions 
require 'fonctions_G12_Compétitions.php';

$competition = array(
        'compe_genre' => $_POST['compe_genre'],
        'compe_nom' => $_POST['compe_nom']
    );


        insertCompetition($competition);
        header("Location: tableselec.php");
 
                

?>

