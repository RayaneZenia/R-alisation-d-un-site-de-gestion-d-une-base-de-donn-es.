<?php
require 'monEnv.php';

function connexion2() {

    $strConnex = "host=" . $_ENV['dbHost'] . " dbname=" . $_ENV['dbName'] . " user=" . $_ENV['dbUser'] . " password=" . $_ENV['dbPasswd'];
    $ptrDB = pg_connect($strConnex);
    return $ptrDB;
}


function getClubById(int $id) : array {
    $ptrDB = connexion2();

    $ptrquery = "SELECT * FROM G12_Clubs WHERE club_id = $1";

 pg_prepare($ptrDB,"reqPrepSelectById",$ptrquery);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectById", array($id));

    if (isset($ptrQuery))
        $resu = pg_fetch_assoc($ptrQuery);
        if (empty($resu))
            $resu =  array("message" => "Identifiant de Club non valide : $id");
            
    pg_free_result($ptrQuery);
    pg_close($ptrDB);

    return $resu;
}

function getAllClubs() : array {
    $ptrDB = connexion2();

    $query = "SELECT * FROM G12_Clubs";
    pg_prepare($ptrDB, "reqPrepSelectAll", $query);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectAll", array());

    $resu = array();

    if (isset($ptrQuery)) {
        while ($row = pg_fetch_assoc($ptrQuery)) {
            $resu[] = $row;
        }
    }
    pg_free_result($ptrQuery);
    pg_close($ptrDB);
    return $resu;
}

function insertClub(array $club) : void {
    $ptrDB = connexion2();

    $query = "INSERT INTO G12_Clubs (club_nom,club_Dcreation,pays_id) VALUES ($1, $2,$3)";
    pg_prepare($ptrDB, "reqPrepInsert", $query);

    // Exécution de la requête INSERT avec les valeurs fournies
    $ptrQuery = pg_execute($ptrDB, "reqPrepInsert", array(
       
        $club['club_nom'],
        $club['club_dcreation'],
        $club['pays_id']
        
    ));

   
}

function updateClub(array $club): array  {
    $ptrDB = connexion2();

     $query = "UPDATE G12_Clubs SET club_nom = $2 WHERE club_id = $1";
    pg_prepare($ptrDB, "reqPrepUpdate", $query);

   
    $ptrQuery = pg_execute($ptrDB, "reqPrepUpdate", array(
        $club['club_id'],
        $club['club_nom']
    ));

    return getClubById($club['club_id']);
}

function deleteClub(string $id): void  {
    $ptrDB = connexion2();

     $query = "DELETE FROM G12_Clubs WHERE club_id = $1";
    pg_prepare($ptrDB, "reqPrepDelete", $query);


    pg_execute($ptrDB, "reqPrepDelete", array($id));
    pg_close($ptrDB);

    }


?>
