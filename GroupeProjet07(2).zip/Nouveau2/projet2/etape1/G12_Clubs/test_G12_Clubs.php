<?php
require_once 'fonction_G12_Clubs.php';

// Test de getClubById() 
echo " A<br />";
print_r(getClubById(2));
echo " A<br />";
echo " B<br />";
print_r(getClubById(111));
echo " B<br />";

// Test de insertClub() 
echo " C<br />";
$club = getClubById(1);
$club['club_id'] = 113;
insertClub($club);
echo " C<br />";
echo " D<br />";
print_r(getClubById(113));
echo " D<br />";


 //Test de updateClub() 
echo " E<br />";
$club = getClubById('113');
print_r($club);
echo " E<br />";
echo " F<br />";
$club['club_nom'] = 'Real MADRID';
print_r(updateClub($club));
echo " F<br />";

 //Test de deleteClub() 
echo " G<br />";
deleteClub('113');
print_r(getClubById('113'));
echo " G<br />";

// Test de getAllClubs() 
echo " H<br />";
print_r(getAllClubs());
echo " H<br />";

?>