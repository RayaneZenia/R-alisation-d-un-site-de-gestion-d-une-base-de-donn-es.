<?php
//pour utiliser les fonctions 
require 'fonction_G12_Clubs.php';
require '../G12_pays/fonctions_G12_Pays.php';


//recuperation des donnees
$club = array(
    'club_nom' => $_POST['club_nom'],
    'club_dcreation' => $_POST['club_dcreation'],
    'pays_id' => $_POST['pays_id']
);
insertClub($club);
header("Location: tableselec.php");
?>